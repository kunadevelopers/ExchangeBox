<?php 
/*
Внимание! Не удаляйте кавычки при указание ваших значений.
Urgent! Do not delete quotation marks while entering data
*/
$marr=array();
$marr['KEY'] = "Вписать сюда/Write here"; 		// API ключ / API Key
$marr['SECRET'] = "Вписать сюда/Write here"; 	// Секрет ключ / Secret Key
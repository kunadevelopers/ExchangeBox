<?php
/*
Внимание! Не удаляйте кавычки при указание ваших значений.
Urgent! Do not delete quotation marks while entering data
*/
$marr=array();
$marr['KEY'] = ""; 		// API ключ / API Key
$marr['SECRET'] = ""; 	// Секрет ключ / Secret Key

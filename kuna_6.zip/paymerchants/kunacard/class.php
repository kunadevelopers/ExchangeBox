<?php
/*
https://kuna.io/documents/api
*/

if(!class_exists('AP_KunaCardApi')){
  class AP_KunaCardApi{

    private $key = "";
    private $secret="";
    private $test = 0;
    private $super_test = 0;

    function __construct($key,$secret)
    {
      $this->key = trim($key);
      $this->secret = trim($secret);
    }
    protected function sign_new($url, array $data, $tonce)
    {
        if(empty($data)){
          $data='{}';
        }
        else{
          $data= json_encode($data);
        }
        return hash_hmac('sha384', implode('', [
            $url,$tonce,
            $data,
        ]), $this->secret);
        
    }
    protected function sign($url, array $data, $method)
    {
        return hash_hmac('sha256', implode('|', [
            $method,
            $url,
            http_build_query($data),
        ]), $this->secret);
        
    }

    public function withdrawKunaCode($amount, $account, $asset = 'uah')
    {
      $request = $this->request('/v3/auth/withdraw',array('amount' => $amount, 'fields' => array('card_number' => $account),'gateway'=>'payment_card_uah','withdraw_type' => $asset),true,'POST');
      $res = @json_decode($request);
      return $res;
      // if(is_object($res) and $res->result == 1){

      // }
      /* или данные или пустота */

    } 
    
    public function check_order($kuna_id){
  		
  		$request = $this->request('/v3/auth/withdraw/details', array('id'=>$kuna_id),true,'POST');
      $res = @json_decode($request);
      return $res;
  		
  	}	

    public function get_balans(){
      $request = $this->request('/members/me', array(),false,'GET','https://kuna.io/api/v2');
      $res = @json_decode($request);
        $purses = array();
        foreach($res->accounts as $account){
          $currency = trim($account->currency);
          $value = trim($account->balance);
          $purses[$currency] = $value;
        }
        return $purses;
      /* или массив или пустота */

    }

    public function request($api_name, $req = array(),$boo=true,$method='POST',$api_url='https://api.kuna.io')
    {
      //$tonce= get_curl_parser('https://kuna.io/api/v2/timestamp', '', 'merchant', 'kunacard')['output'].'000';
      $tonce  = (int) round(1000*microtime(true));
      //$tonce  = '1556878842731';
      $url    = $api_url . $api_name;

      if($boo){
        //$req['access_key'] = $this->key;
        //$req['tonce'] = '1556878842731';
        ksort($req);
        //$req['signature'] = $this->sign_new($api_name, $req, $tonce) ;
        $signature = $this->sign_new($api_name, $req, $tonce) ;
        $post_data = http_build_query($req, '', '&');
        $url=$url.'?'.$post_data;

      }else{
        ksort($req);
        $signature = $this->sign($api_name, $req, $tonce) ;
        $post_data = http_build_query($req, '', '&');
        $url=$url.'?'.$post_data;
      }

      $post_data = http_build_query($req, '', '&');
      //$sign = hash_hmac('sha256', $post_data, $this->secret);

      $headers = array(
        'Sign: ' . $signature,
        'Key: ' . $this->key,
				'Content-Type: application/json',
        'kun-nonce:'. $tonce,
        'kun-apikey:'. $this->key,
        'kun-signature:'. $signature
      );

      static $ch = null;

      $c_options='' ;
			if(empty($req)){
				$req='{}';
			}
			else{
				$req= json_encode($req);
			}
      if ($boo){
        $c_options = array(
          CURLOPT_CUSTOMREQUEST   => $method,
          CURLOPT_HTTPHEADER      => $headers,
					CURLOPT_POSTFIELDS			=> $req
        );
      }

      // if($boo){
      //     echo $url;
      //     exit;
      // }

      $result = get_curl_parser($url, $c_options, 'merchant', 'kunacard');
      $err  = $result['err'];
      $out = $result['output'];

      if(!$err){
        if($this->test==1 ){
          echo $out;
          exit;
        }
        return $out;
      }
      elseif($this->test==1 ){
        echo $err;
        exit;
      }
    }

  }
}

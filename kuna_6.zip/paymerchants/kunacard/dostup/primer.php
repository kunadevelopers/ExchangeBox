<?php 
/*
Внимание! Не удаляйте кавычки при указание ваших значений.
Urgent! Do not delete quotation marks while entering data.
*/
$marr = array();
$marr['BUTTON'] = "Вписать сюда/Write here"; 	// Разрешить использование кнопки для подтверждения оператором авто выплаты в админке (0-нет, 1-да) / Enable the button, which responds to an automatic payout confirmation by an operator through an Admin panel (0-No, 1- Yes)
$marr['KEY'] = "Вписать сюда/Write here"; 		// API ключ / API Key 
$marr['SECRET'] = "Вписать сюда/Write here"; 	// Секрет ключ / Secret Key
<?php
/*
title: [en_US:]Kuna[:en_US][ru_RU:]Kuna[:ru_RU]
description: [en_US:]Kuna automatic payouts[:en_US][ru_RU:]авто выплаты Kuna[:ru_RU]
version: 1.5
*/
if(!class_exists('paymerchant_kunacard')){
	class paymerchant_kunacard extends AutoPayut_Premiumbox{

		function __construct($file, $title)
		{
			$map = array(
				'BUTTON', 'KEY', 'SECRET',
			);
			parent::__construct($file, $map, $title, 'BUTTON');

			add_action('get_paymerchant_admin_options_'.$this->name, array($this, 'get_paymerchant_admin_options'), 10, 2);
			add_filter('paymerchants_settingtext_'.$this->name, array($this, 'paymerchants_settingtext'));
			add_filter('reserv_place_list',array($this,'reserv_place_list'));
			add_filter('list_user_notify',array($this,'user_mailtemp'));
			add_filter('list_notify_tags_kunacard_paycoupon',array($this,'mailtemp_tags_paycoupon'));
			add_filter('update_currency_autoreserv', array($this,'update_currency_autoreserv'), 10, 3);
			add_filter('update_direction_reserv', array($this,'update_direction_reserv'), 10, 3);
			add_action('myaction_merchant_ap_'.$this->name.'_cron' . get_hash_result_url($this->name, 'ap'), array($this,'myaction_merchant_cron'));
		}

		function security_list(){
			return array('show_error');
		}

		function get_paymerchant_admin_options($options, $data){

			if(isset($options['note'])){
				unset($options['note']);
			}
			if(isset($options['checkpay'])){
				unset($options['checkpay']);
			}
			if(isset($options['resulturl'])){
				unset($options['resulturl']);
			}
			$options['public_key'] = array(
				'view' => 'input',
				'title' => __('Public key','pn'),
				'default' => is_isset($data, 'public_key'),
				'name' => 'public_key',
				'work' => 'symbols',
			);
			$options['privat_key'] = array(
				'view' => 'input',
				'title' => __('Privat key','pn'),
				'default' => is_isset($data, 'privat_key'),
				'name' => 'privat_key',
				'work' => 'symbols',
			);
			$text = '
			<strong>CRON:</strong> <a href="'. get_merchant_link('ap_'. $this->name .'_cron' . get_hash_result_url($this->name, 'ap')) .'" target="_blank">'. get_merchant_link('ap_'. $this->name .'_cron' . get_hash_result_url($this->name, 'ap')) .'</a>
			';
			$options[] = array(
				'view' => 'textfield',
				'title' => '',
				'default' => $text,
			);		

			return $options;
		}

		function paymerchants_settingtext(){
			$text = '| <span class="bred">'. __('Config file is not set up','pn') .'</span>';
			if(
				is_deffin($this->m_data,'KEY')
				and is_deffin($this->m_data,'SECRET')
			){
				$text = '';
			}

			return $text;
		}

		function user_mailtemp($places_admin){

			$places_admin['kunacard_paycoupon'] = sprintf(__('%s automatic payout','pn'), 'Kuna Card');

			return $places_admin;
		}

		function mailtemp_tags_paycoupon($tags){

			$tags['id'] = __('Kuna Card','pn');
			$tags['bid_id'] = __('Order ID','pn');

			return $tags;
		}

		function get_reserve_lists(){

			$purses = array(
				$this->name.'_1' => 'UAH',
			);

			return $purses;
		}

		function reserv_place_list($list){

			$purses = $this->get_reserve_lists();
			foreach($purses as $k => $v){
				$list[$k] = 'Kuna Card '. $v.' ['. $this->name .']';
			}

			return $list;
		}

		function update_currency_autoreserv($ind, $key, $currency_id){
			$ind = intval($ind);
			if($ind == 0){
				if($this->check_reserv_list($key)){
					$purses = $this->get_reserve_lists();
					$purse = trim(is_isset($purses, $key));
					if($purse){
						try{
							$public_key = get_option('paymerch_data')['kunacard']['public_key'] ?: NULL;
							$privat_key = get_option('paymerch_data')['kunacard']['privat_key'] ?: NULL;
							$oClass = new AP_KunaCardApi($public_key,$privat_key);
							$res = $oClass->get_balans();
							if(is_array($res)){
								$rezerv = '-1';
								foreach($res as $pursename => $amount){
									if( $pursename == $purse ){
										$rezerv = trim((string)$amount);
										break;
									}
								}
								if($rezerv != '-1'){
									pm_update_vr($currency_id, $rezerv);
								}
							}
						}
						catch (Exception $e)
						{
						}
						return 1;
					}
				}
			}
			return $ind;
		}

		function update_direction_reserv($ind, $key, $direction_id){
			$ind = intval($ind);
			if(!$ind){
				if($this->check_reserv_list($key)){
					$purses = $this->get_reserve_lists();
					$purse = trim(is_isset($purses, $key));
					if($purse){
						try{
							$public_key = get_option('paymerch_data')['kunacard']['public_key'] ?: NULL;
							$privat_key = get_option('paymerch_data')['kunacard']['privat_key'] ?: NULL;
							$oClass = new AP_KunaCardApi($public_key,$privat_key);
							$res = $oClass->get_balans();
							if(is_array($res)){
								$rezerv = '-1';
								foreach($res as $pursename => $amount){
									if( $pursename == $purse ){
										$rezerv = trim((string)$amount);
										break;
									}
								}
								if($rezerv != '-1'){
									pm_update_nr($direction_id, $rezerv);
								}
							}
						}
						catch (Exception $e)
						{
						}
						return 1;
					}
				}
			}
			return $ind;
		}

		function do_auto_payouts($error, $pay_error, $item, $direction_data, $paymerch_data, $unmetas, $place, $modul_place){
			$item_id = $item->id;
			$trans_id = 0;
			$coupon = '';
			$vtype = mb_strtoupper($item->currency_code_get);
			$vtype = str_replace('UAH','UAH',$vtype);

			$enable = array('UAH');
			if(!in_array($vtype, $enable)){
				$error[] = __('Wrong currency code','pn');
			}
			$account = $item->account_get;
			$account = preg_replace('/\s/', '', $account);
			if (strlen($account)!=16&&!is_numeric($account)) {
				$error[] = __('Payout error','pn');
			}
			$sum = is_paymerch_sum($this->name, $item, $paymerch_data);

			$two = array('UAH');
			if(in_array($vtype, $two)){
				$sum = is_sum($sum, 8);
			} else {
				$sum = is_sum($sum);
			}
			if(count($error) == 0){

				$result = $this->set_ap_status($item);
				if($result){

					try{
						$public_key = get_option('paymerch_data')['kunacard']['public_key'] ?: NULL;
						$privat_key = get_option('paymerch_data')['kunacard']['privat_key'] ?: NULL;
						$res = new AP_KunaCardApi($public_key,$privat_key);
						$res = $res->withdrawKunaCode($sum,$account)[0];	
						if(in_array("account_balance_is_poor", $res->messages)){
							$error[] = __('Payout error','pn');
							$pay_error = 1;
						}else{
							if($res->status=='pending'||$res->status=='success'){
								$trans_id = $res->withdrawal_id;
							}else{
								$error[] = __('Payout error','pn');
								$pay_error = 1;
							}
						}

					}
					catch (Exception $e)
					{
						$error[] = $e->getMessage();
						$pay_error = 1;
					}

				} else {
					$error[] = 'Database error';
				}

			}

			if(count($error) > 0){

				$this->reset_ap_status($error, $pay_error, $item, $place);

			} else {



				$params = array(
					'trans_out' => $trans_id,
					'system' => 'user',
					'ap_place' => $place,
					'm_place' => $modul_place. ' ' .$this->name,
				);
				the_merchant_bid_status('coldsuccess', $item_id, $params, 1);	 	

				if($place == 'admin'){
					pn_display_mess(__('Payment is successfully created. Waiting for confirmation from Kuna.','pn'),__('Payment is successfully created. Waiting for confirmation from Kuna.','pn'),'true');
				}

			}
		}
		
			function myaction_merchant_cron(){
				global $wpdb;
				$m_out = $this->name;
				
				$data = get_paymerch_data($this->name);
				$error_status = is_status_name(is_isset($data, 'error_status'));
				if(!$error_status){ $error_status = 'realpay'; }
				
				$items = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."exchange_bids WHERE status = 'coldsuccess' AND m_out='$m_out'");
				$public_key = get_option('paymerch_data')['kunacard']['public_key'] ?: NULL;
				$privat_key = get_option('paymerch_data')['kunacard']['privat_key'] ?: NULL;
				foreach($items as $item){
					$trans_id = trim($item->trans_out);
					if($trans_id){					
					try {
						
							$oClass = new AP_KunaCardApi($public_key,$privat_key);
							$res = $oClass->check_order($trans_id);
							if(isset($res->status)){
								if($res->status == 'done'){
									$params = array(
										'system' => 'system',
										'ap_place' => 'site',
										'm_place' => 'cron ' .$this->name,
									);
									the_merchant_bid_status('success', $item->id, $params, 1);														
								} elseif($res->status != 'pending'||$res->status != 'awaiting_confirmation') {
									send_paymerchant_error($item->id, __('Your payment is declined','pn'));
									update_bids_meta($item->id, 'ap_status', 0);
									update_bids_meta($item->id, 'ap_status_date', current_time('timestamp'));
									$arr = array(
										'status'=> $error_status,
										'edit_date'=> current_time('mysql'),
									);									
									$wpdb->update($wpdb->prefix.'exchange_bids', $arr, array('id'=>$item->id));
								}
							}
						
						}
						catch( Exception $e ) {
									
						}
					
					}
				
				
			}
			_e('Done','pn');
		}	
	}
}

new paymerchant_kunacard(__FILE__, 'Kuna Card');
